const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
require('dotenv').config();

const commands = [
  new SlashCommandBuilder().setName('ping').setDescription('Bot antwortet mit Pong!'),
  new SlashCommandBuilder().setName('eventstart').setDescription('Startet ein Community-Event'),
  new SlashCommandBuilder().setName('eventstop').setDescription('Beendet das laufende Event'),
  new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Einen User kicken')
    .addUserOption(option => option.setName('user').setDescription('User zum Kicken').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Einen User bannen')
    .addUserOption(option => option.setName('user').setDescription('User zum Bannen').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  new SlashCommandBuilder()
    .setName('warn')
    .setDescription('User verwarnen')
    .addUserOption(option => option.setName('user').setDescription('User zum Verwarnen').setRequired(true))
    .addStringOption(option => option.setName('grund').setDescription('Grund der Verwarnung').setRequired(true)),
  new SlashCommandBuilder()
    .setName('warnliste')
    .setDescription('Verwarnungen eines Users anzeigen')
    .addUserOption(option => option.setName('user').setDescription('User').setRequired(true))
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);

(async () => {
  try {
    console.log('🔄 Registriere Slash-Commands...');
    await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), {
      body: commands
    });
    console.log('✅ Befehle erfolgreich registriert.');
  } catch (error) {
    console.error(error);
  }
})();
