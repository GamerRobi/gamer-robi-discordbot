const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
require('dotenv').config();

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.Channel]
});

const warnungen = new Map();

client.once('ready', () => {
  console.log(`🤖 Bot online als ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  const { commandName, options } = interaction;

  if (commandName === 'ping') {
    await interaction.reply('🏓 Pong!');
  } else if (commandName === 'eventstart') {
    await interaction.reply('📢 Ein Event wurde gestartet!');
  } else if (commandName === 'eventstop') {
    await interaction.reply('🛑 Das Event wurde gestoppt.');
  } else if (commandName === 'kick') {
    const member = options.getMember('user');
    if (member.kickable) {
      await member.kick();
      await interaction.reply(`✅ ${member.user.tag} wurde gekickt.`);
    } else {
      await interaction.reply('⚠️ Ich kann diesen Nutzer nicht kicken.');
    }
  } else if (commandName === 'ban') {
    const member = options.getMember('user');
    if (member.bannable) {
      await member.ban();
      await interaction.reply(`⛔ ${member.user.tag} wurde gebannt.`);
    } else {
      await interaction.reply('⚠️ Ich kann diesen Nutzer nicht bannen.');
    }
  } else if (commandName === 'warn') {
    const user = options.getUser('user');
    const grund = options.getString('grund');
    const warns = warnungen.get(user.id) || [];
    warns.push({ grund, zeit: new Date().toLocaleString() });
    warnungen.set(user.id, warns);
    await interaction.reply(`⚠️ ${user.tag} wurde verwarnt: ${grund}`);
  } else if (commandName === 'warnliste') {
    const user = options.getUser('user');
    const warns = warnungen.get(user.id) || [];
    if (warns.length === 0) {
      await interaction.reply(`${user.tag} hat keine Verwarnungen.`);
    } else {
      const list = warns.map((w, i) => `${i + 1}. ${w.grund} (${w.zeit})`).join('\n');
      await interaction.reply(`📄 Verwarnungen für ${user.tag}:
${list}`);
    }
  }
});

client.login(process.env.BOT_TOKEN);
