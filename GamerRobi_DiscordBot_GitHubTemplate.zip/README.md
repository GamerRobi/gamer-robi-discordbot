
# GamerRobi Discord Bot + Admin Dashboard

Ein vollständiges Projekt mit Slash-Befehlen, Moderation, Eventsteuerung und Web-Dashboard mit Discord-Login.

---

## 📦 Features

- ✅ Discord-Bot mit Slash Commands (`/kick`, `/ban`, `/warn`, `/eventstart`, ...)
- ✅ Event-Management & Verwarnungssystem
- ✅ Admin Dashboard mit Discord-OAuth2-Login
- ✅ Web-GUI zur Anzeige von Verwarnungen
- ✅ Bereit für Hosting auf Railway oder Replit

---

## 🚀 Hosting auf Railway

1. Repository forken oder klonen
2. Railway Account erstellen: [https://railway.app](https://railway.app)
3. Neues Projekt > GitHub Repo auswählen
4. Variablen im Railway Dashboard setzen:

```
BOT_TOKEN=dein-discord-token
CLIENT_ID=deine-discord-client-id
CLIENT_SECRET=dein-client-secret
GUILD_ID=dein-discord-server-id
CALLBACK_URL=https://dein-projekt.up.railway.app/callback
```

5. Start Command:
```
cd bot && node index.js
```

Optional (Admin-Panel):
```
cd dashboard/server && node server.js
```

---

## 🛠 Projektstruktur

```
📁 bot
  ├── index.js              # Bot Logik
  ├── deploy-commands.js    # Slash-Commands registrieren
  └── .env.example

📁 dashboard
  ├── index.html            # Admin GUI
  ├── warnungen.html        # Webinterface Verwarnungen
  └── server
      ├── server.js         # Express + Discord Login
      ├── warn-api.js       # API für Verwarnungsliste
      └── .env.example
```

---

## 📄 Lizenz

MIT – Frei nutzbar & anpassbar mit Credits an Gamer Robi
