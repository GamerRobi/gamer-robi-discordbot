
const express = require('express');
const router = express.Router();

// Beispielhafte Verwarnungsdaten (in-memory)
const warnungen = {
  '123456789012345678': [
    { grund: 'Spam im Chat', zeit: '18.05.2025, 12:34' },
    { grund: 'Unangemessenes Verhalten', zeit: '18.05.2025, 14:15' }
  ]
};

// API-Endpunkt: GET /api/warnungen/:userId
router.get('/warnungen/:userId', (req, res) => {
  const userId = req.params.userId;
  res.json(warnungen[userId] || []);
});

module.exports = router;
